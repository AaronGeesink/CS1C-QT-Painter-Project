var searchData=
[
  ['begin',['begin',['../classproject_1_1vector.html#a324695bbd462ffcced50b8f3ac75ca68',1,'project::vector::begin()'],['../classproject_1_1vector.html#ac10d2b8ac2cee034dddadc2b7f06b9de',1,'project::vector::begin() const']]],
  ['brush',['brush',['../class_shapes_1_1_shape.html#a72286d8293ed7af6409ebd5d5e143e2f',1,'Shapes::Shape']]]
];
