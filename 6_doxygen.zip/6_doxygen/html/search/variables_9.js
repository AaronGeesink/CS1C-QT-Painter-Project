var searchData=
[
  ['text',['text',['../class_shapes_1_1_text.html#a57f9b6c97cde2afaa0f0cf17ac333534',1,'Shapes::Text']]]
];
