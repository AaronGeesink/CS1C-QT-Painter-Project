var searchData=
[
  ['text',['Text',['../class_shapes_1_1_text.html',1,'Shapes']]]
];
