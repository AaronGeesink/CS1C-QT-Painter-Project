var searchData=
[
  ['rectangle',['Rectangle',['../class_shapes_1_1_rectangle.html#a7af6fa758756ec3abcf981433d5744a1',1,'Shapes::Rectangle']]],
  ['reserve',['reserve',['../classproject_1_1vector.html#ab1cd63b3d7cd670c1b5c001513772d27',1,'project::vector']]],
  ['resize',['resize',['../classproject_1_1vector.html#a48ef25366c7155a905a0f2d4fa97f4fa',1,'project::vector']]]
];
