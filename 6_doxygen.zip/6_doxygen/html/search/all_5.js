var searchData=
[
  ['font',['font',['../class_shapes_1_1_text.html#a4fc93ca4f83f1e9796f017a9867533d1',1,'Shapes::Text']]]
];
