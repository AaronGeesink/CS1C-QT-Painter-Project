var searchData=
[
  ['alignment',['alignment',['../class_shapes_1_1_text.html#a5282c9fd296e6629c6e6d89acb1b6a84',1,'Shapes::Text']]],
  ['area',['area',['../class_shapes_1_1_shape.html#ac0f41bac6a74b5eeb5fa495be3095f22',1,'Shapes::Shape']]]
];
