var searchData=
[
  ['insert',['insert',['../classproject_1_1vector.html#a679394aec4be2d7ceea3261e47302545',1,'project::vector']]]
];
