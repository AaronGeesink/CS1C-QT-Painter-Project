var searchData=
[
  ['getbrush',['getBrush',['../class_shapes_1_1_shape.html#a255da1a57c86e174814a7a2362d9d80f',1,'Shapes::Shape']]],
  ['getid',['getId',['../class_shapes_1_1_shape.html#ad24c5659cb3bdbeb8881b62a8402df98',1,'Shapes::Shape']]],
  ['getpen',['getPen',['../class_shapes_1_1_shape.html#a36626740992caa7eeb58d70efb9174c4',1,'Shapes::Shape']]],
  ['getqpainter',['getQPainter',['../class_shapes_1_1_shape.html#a99a2aa6dd5b038a42e6a8c1eafb7dd4d',1,'Shapes::Shape']]],
  ['getshape',['getShape',['../class_shapes_1_1_shape.html#aed92280d4653c351877f2b8bf3afe71a',1,'Shapes::Shape']]],
  ['getx',['getX',['../class_shapes_1_1_shape.html#ae5f2a50855d92cc52b3a2672f829ee0d',1,'Shapes::Shape']]],
  ['gety',['getY',['../class_shapes_1_1_shape.html#abe6d252fc7ead847c25267d891c28793',1,'Shapes::Shape']]]
];
