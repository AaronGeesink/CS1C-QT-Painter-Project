var searchData=
[
  ['x',['x',['../class_shapes_1_1_shape.html#a385551a5a233659cebf7f908a2420467',1,'Shapes::Shape']]]
];
