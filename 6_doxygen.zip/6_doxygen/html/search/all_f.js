var searchData=
[
  ['text',['Text',['../class_shapes_1_1_text.html',1,'Shapes::Text'],['../class_shapes_1_1_text.html#a57f9b6c97cde2afaa0f0cf17ac333534',1,'Shapes::Text::text()'],['../class_shapes_1_1_text.html#a67b82d97330d70e7146277e9afaa5cea',1,'Shapes::Text::Text(QPainter *painter=nullptr, int id=-1)']]]
];
