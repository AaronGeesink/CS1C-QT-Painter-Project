var searchData=
[
  ['text',['Text',['../class_shapes_1_1_text.html#a67b82d97330d70e7146277e9afaa5cea',1,'Shapes::Text']]]
];
