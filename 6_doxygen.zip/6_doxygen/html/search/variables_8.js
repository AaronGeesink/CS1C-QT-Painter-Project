var searchData=
[
  ['shape',['shape',['../class_shapes_1_1_shape.html#aa9ab2960b0e2e4fe5493715158842087',1,'Shapes::Shape']]],
  ['size_5fv',['size_v',['../classproject_1_1vector.html#a0bbf544d7037538d4d4bbfdbfc45e0b1',1,'project::vector']]],
  ['space',['space',['../classproject_1_1vector.html#ad791b8839a1ca0af6dcb2120057f916e',1,'project::vector']]]
];
