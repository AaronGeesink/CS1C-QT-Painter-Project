var searchData=
[
  ['brush',['brush',['../class_shapes_1_1_shape.html#a72286d8293ed7af6409ebd5d5e143e2f',1,'Shapes::Shape']]]
];
