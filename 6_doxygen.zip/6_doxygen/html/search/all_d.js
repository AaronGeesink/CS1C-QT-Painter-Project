var searchData=
[
  ['rect',['rect',['../class_shapes_1_1_rectangle.html#ac83ff3de5cd912036dabdf0250644c13',1,'Shapes::Rectangle::rect()'],['../class_shapes_1_1_ellipse.html#a14774fda159975bb6e35d34e1a7a3fc8',1,'Shapes::Ellipse::rect()'],['../class_shapes_1_1_text.html#a50081bcc4e4222edd098251d7d08bc4d',1,'Shapes::Text::rect()']]],
  ['rectangle',['Rectangle',['../class_shapes_1_1_rectangle.html',1,'Shapes::Rectangle'],['../class_shapes_1_1_rectangle.html#a7af6fa758756ec3abcf981433d5744a1',1,'Shapes::Rectangle::Rectangle()']]],
  ['reserve',['reserve',['../classproject_1_1vector.html#ab1cd63b3d7cd670c1b5c001513772d27',1,'project::vector']]],
  ['resize',['resize',['../classproject_1_1vector.html#a48ef25366c7155a905a0f2d4fa97f4fa',1,'project::vector']]]
];
